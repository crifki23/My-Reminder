package com.example.myreminder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button lokasi, alarm, event;
    TextView namelabel, suhulabel, kelembabanlabel;
    FirebaseAuth fAuth;
    String userId;
    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        namelabel=findViewById(R.id.txtnamefield);
        suhulabel=findViewById(R.id.txtsuhufield);
        kelembabanlabel=findViewById(R.id.txtkelembabanfield);
        lokasi = findViewById(R.id.btnlokasi);
        alarm = findViewById(R.id.btnalarm);
        event = findViewById(R.id.btncalender);

        fAuth=FirebaseAuth.getInstance();
        userId=fAuth.getCurrentUser().getUid();
        reference=FirebaseDatabase.getInstance().getReference().child("users").child(userId);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name=snapshot.child("nama").getValue().toString();
                namelabel.setText(name);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        reference=FirebaseDatabase.getInstance().getReference().child("dht22");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String suhu=snapshot.child("suhu").getValue().toString();
                String kelembaban=snapshot.child("kelembaban").getValue().toString();
                suhulabel.setText(suhu);
                kelembabanlabel.setText(kelembaban);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        lokasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), lokasi.class);
                startActivity(i);
            }
        });
        alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), alarm.class);
                startActivity(i);
            }
        });
        event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(), kalender.class);
                startActivity(i);
            }
        });
    }


    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        finish();
    }
}
