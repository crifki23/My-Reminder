package com.example.myreminder;

public class UserHelperClass {
    String name,email;

    public UserHelperClass() {
    }

    public UserHelperClass(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getNama() {
        return name;
    }

    public void setNama(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
