package com.example.myreminder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {
    EditText memail,mpassword, mfullname;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    FirebaseAuth fAuth;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mfullname=findViewById(R.id.txtnamereg);
        memail=findViewById(R.id.txtemailreg);
        mpassword=findViewById(R.id.txtpasswordreg);
        fAuth=FirebaseAuth.getInstance();
        rootNode=FirebaseDatabase.getInstance();
    }

    public void Register(View view) {
        final String name=mfullname.getText().toString();
        final String email=memail.getText().toString().trim();
        String password=mpassword.getText().toString().trim();
        if(TextUtils.isEmpty(name)){
            mfullname.setError("Nama tidak boleh kosong");
            return;
        }
        if(TextUtils.isEmpty(email)){
            memail.setError("Email tidak boleh kosong");
            return;
        }
        if(TextUtils.isEmpty(password)){
            mpassword.setError("Password tidak boleh kosong");
            return;
        }
        fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    reference=rootNode.getReference("users");
                    Toast.makeText(register.this, "Data Telah Disimpan", Toast.LENGTH_SHORT).show();
                    userId=fAuth.getCurrentUser().getUid();
                    UserHelperClass helperClass=new UserHelperClass(name,email);
                    reference.child(userId).setValue(helperClass);
                    startActivity(new Intent(getApplicationContext(),MainActivity.class));
                }else{
                    Toast.makeText(register.this, "Error : "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}